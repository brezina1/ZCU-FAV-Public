function p = nurbsEval(d,c,w,k,u)
% p = nurbsbspeval(d,c,k,u)
% NURBSEVAL  Vyhodnocuje bod NURBS funkce pro vektor parametru u
% 
% Vstupy:
% 
%       d - stupen B-spline (rad po castech polynom.fce)
%       c - vektor nc ridicich bodu o rozmeru m, matice dimenze (m,nc).
%       w - vahove koeficienty ridicich bodu pro racionalni zobecneni krivky - vektor o delce (1,nc)
%       k - uzlovy vektor o delce nk.
%       u - vektor hodnot parametru u, pro ktere ma byt krivka vyhodnocena o delce nu.
% 
% Vystup:
%
%       p - Hodnoty NURBS funkce pro parametry z vektoru u, matice dimenze (dim,nu)
% 
% Algoritmus je standardni rekurzivni Cox-De Boorovo formuli zobecnenou pro
% racionalni specializaci krivky

nu = numel(u);
[mc,nc] = size(c);
                                                %   int bspeval(int d, double *c, int mc, int nc, double *k, int nk, double *u,int nu, double *p){
                                                %   int ierr = 0;
                                                %   int i, s, tmp1, row, col;
                                                %   double tmp2;
                                                %
                                                %   // Construct the control points
                                                %   double **ctrl = vec2mat(c,mc,nc);
                                                %
                                                %   // Contruct the evaluated points
p = zeros(mc,nu);                               %   double **pnt = vec2mat(p,mc,nu);
                                                %
                                                %   // space for the basis functions
N = zeros(d+1,1);                               %   double *N = (double*) mxMalloc((d+1)*sizeof(double));
                                                %
                                                %   // for each parametric point i
for col=1:nu                                    %   for (col = 0; col < nu; col++) {
                                                %     // find the span of u[col]
    s = findSpan(nc-1, d, u(col), k);           %     s = findspan(nc-1, d, u[col], k);
    N = basisFunctions(s,u(col),d,k);                 %     basisfun(s, u[col], d, k, N);
                                                %
    tmp1 = s - d + 1;                           %     tmp1 = s - d;
    for row=1:mc                                %     for (row = 0; row < mc; row++)  {
        num = 0;
        den = 0;                                %       tmp2 = 0.0;
        for i=0:d                               %       for (i = 0; i <= d; i++)
           num = num + N(i+1)*c(row,tmp1+i)*w(tmp1+i);  % 	tmp2 += N[i] * ctrl[tmp1+i][row];
           den = den + N(i+1)*w(tmp1+i);
        end                                     %
        p(row,col) = num/den;                      %       pnt[col][row] = tmp2;
    end                                         %     }
end                                             %   }
                                                %
                                                %   mxFree(N);
                                                %   freevec2mat(pnt);
                                                %   freevec2mat(ctrl);
                                                %
                                                %   return ierr;
                                                %   }
