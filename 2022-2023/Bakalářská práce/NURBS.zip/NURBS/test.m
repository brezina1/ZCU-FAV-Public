clc;
clear;
close all;

Q_k = [0 0; 1 0.5; 2 3; 3 3; 4 3; 5 0.5; 6 0];


for algorithm = ["EquallySpaced", "ChordLength", "CentripetalMethod"]
    d = 3;
    figure;
    plot(Q_k(:, 1), Q_k(:, 2), 'ro');
    hold on;

    [U_bar, U, P] = globalCurveInterpolation(Q_k, d, algorithm);

    point_count = 1000; %pocet generovanych bodu krivky pro vykresleni grafu
    weights = ones(1, length(Q_k)); %vahove funkce pro neracionalni B-spline
    u = linspace(0, 1, point_count ); %m pozad. bodu parametrickeho vektoru

    p = nurbsEval(d, P', weights, U, u); %vygenerovani bodu funkce

    plot(p(1, :), p(2, :));

    Q_k_new = Q_k;
    
    weights = ones(1, length(Q_k_new));
    
%   weights(4) = 2;
    % počet řídících bodů
    n = 6;

    [U_bar_new, U_new, P_new]= globalCurveApproximation2(Q_k_new, weights, n , d);

    u = linspace(0, 1, point_count ); %m pozad. bodu parametrickeho vektoru
    p = nurbsEval(d, P_new', weights, U_new, u); %vygenerovani bodu funkce

    hold on;
    plot(p(1, :), p(2, :));
    
    legend()
end