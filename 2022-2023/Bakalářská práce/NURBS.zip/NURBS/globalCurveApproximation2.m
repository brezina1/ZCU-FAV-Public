function [U_bar, U, P] = globalCurveApproximation2(Q, Wq, n, p)
%GLOBALCURVEAPPROXIMATION Summary of this function goes here
% Strana 415 
%   Q   = body
%   Wq  = váhy bodů (Wq(i) > 0 => Q(i) je neomezený a w_i je jeho váha
%                   Wq(i) < 0 => Q(i) je omezený
%   n   = aproximace s n + 1 řídícími body
%   p   = aproximace křivkou se stupněm p

r = length(Q) - 1;

r_u = -1;
r_c = -1;

for i = 0 : r
    if (Wq(i + 1) > 0)
        r_u = r_u + 1;
    else
        r_c = r_c + 1;
    end
end
s_u = -1;
s_c = -1;
m_u = r_u + s_u + 1;
m_c = r_c + s_c + 1;

if (m_c >= n || m_c + n >= m_u + 1)
    error("m_c >= n || m_c + n >= m_u + 1");
end

% d=0;
% d_celk=0;
% 
% for i=2:n
%     d(i-1)=norm(Q(i,:)-Q(i-1,:));
%     d_celk=d_celk+d(i-1);
% end;

%Vypocet vektoru parametru u_p pro vsechny body, pro ktere budou vycisleny baz.fce podle
%chordalove parametrizace
% U_bar=0;
% for i=1:n-1
%     U_bar(i+1)=U_bar(i)+d(i)/d_celk;
% end;


% U_bar = computeU_bar(Q, "EquallySpaced");
U_bar = computeU_bar(Q, "ChordLength");
% Eq 9.68
d = (r + 1)/(n - p + 1);
% Eq 9.69
U = zeros(1, 2*(p + 1) + n - p);

for j = 1 : n - p
    i = floor(j * d);
    alpha = j * d - i;
    U(p + j + 1) = (1 - alpha) * U_bar(i) + alpha * U_bar(i + 1);
end
U(n + 1 + 1 : end) = ones(1, p + 1);


% for j = 1 : n - p
%     U(j + p + 1) = 1/p * sum(U_bar(j + 1 : j + p));
% end
% U(n + 1 + 1 : end) = ones(1, p + 1);


[~, dimensions] = size(Q);
% neomezené body
S = nan(m_u + 1, dimensions);
% omezené body
T = nan(m_c + 1, dimensions);

% matice bázových funkcí pro neomezené body
N = nan(m_u + 1, n + 1);
% matice bázových funkcí pro omezené body
M = nan(m_c + 1, n + 1);
% matice s váhami na diagonále (m_u + 1) x (m_u + 1)
W = diag(Wq(Wq > 0));


m_u2 = 1;
m_c2 = 1;
for i = 1 : r + 1
    span = findSpan(n, p, U_bar(i), U);
    funs = basisFunctions(span, U_bar(i), p, U);

    if (Wq(i) > 0)
        % neomezený bod
        N(m_u2, :) = [zeros(1, span - p) funs zeros(1, n - span)];
        W(m_u2, m_u2) = Wq(i);
        
%         S(m_u2, :) = [Q(i, 1), W(m_u2, m_u2) * Q(i, 2: end)];
        S(m_u2, :) = W(m_u2, m_u2) *Q(i, :);
        m_u2 = m_u2 + 1;
    else
        % omezený bod
        M(m_c2, :) = [zeros(1, span - p) funs zeros(1, n - span)];

        T(m_c2, :) = Q(i, :);
        m_c2 = m_c2 + 1;
    end
end

if (m_c < 0)
%     % žádné omezené body
    P = N \ S;
    return;
end

A = (M * (N' * W * N)^-1 * M') ^-1 *  (M * (N' * W * N)^-1 * N' * W * S - T);
P = (N' * W * N)^-1 * ((N' * W * S) - M' * A);
end

